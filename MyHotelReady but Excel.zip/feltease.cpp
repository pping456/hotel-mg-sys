#include <iostream>
#include <fstream>
#include <ctime>
#include <limits>
#include <cctype>
#include <cstdlib>  // for exit()
#include <string>
using namespace std;

// ---------------Use Of Validation-------------
int validNumber() 
{
    int n;
    while (!(cin >> n) || n < 0) 
	{
        cout << "Invalid input. Enter a positive number: ";
        cin.clear();
        cin.ignore(1000, '\n');
    }
    return n;
}

float validFloat() 
{
    float f;
    while (!(cin >> f) || f < 0) 
	{
        cout << "Invalid input. Enter a positive float: ";
        cin.clear();
        cin.ignore(1000, '\n');
    }
    return f;
}

string validString() 
{
    string s;
    bool valid;
    do 
	{
        valid = true;
        cin >> s;
        for (char c : s) 
		{
            if (!isalpha(c)) 
			{
                valid = false;
                break;
            }
        }
        if (!valid) 
		{
            cout << "Invalid input. Enter alphabetic characters only: ";
        }
    } while (!valid);
    return s;
}

string validName() {
    string name;

    // flush leftover newline only once
    cin.ignore(numeric_limits<streamsize>::max(), '\n');  

    while (true) {
        cout << "Enter Name: ";
        getline(cin, name);

        if (!name.empty()) {
            bool ok = true;
            for (char c : name) {
                if (!(isalpha(c) || isspace(c))) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                return name; // ? Only letters + spaces allowed
            }
        }

        cout << "? Invalid name! Only alphabets and spaces are allowed.\n";
    }
}

string validAddress() {
    string address;

    // flush leftover newline only once
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    while (true) {
        cout << "Enter Address: ";
        getline(cin, address);

        if (!address.empty()) {
            bool ok = true;
            for (char c : address) {
                if (!(isalnum(c) || isspace(c) || c == ',' || c == '.' || c == '-' || c == '#' || c == '/')) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                return address; // ? return if valid
            }
        }

        cout << "? Invalid address! Only letters, numbers, spaces and , . - # / are allowed.\n";
    }
}


string validContactNumber() {
    string number;
    bool isValid = false;

    // clear leftover newline only once before first getline
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    do {
        cout << "Enter Contact Number: ";
        cin >> number;

        // Empty check
        if (number.empty()) {
            cout << "? Contact number cannot be empty. Try again.\n";
            continue;
        }

        // Case 1: Starts with +92
        if (number.rfind("+92", 0) == 0) {
            if (number.length() != 13) {
                cout << "? Must be '+92' followed by exactly 10 digits.\n";
                continue;
            }
            bool digitsOnly = true;
            for (int i = 3; i < number.length(); i++) {
                if (!isdigit(number[i])) {
                    digitsOnly = false;
                    break;
                }
            }
            if (!digitsOnly) {
                cout << "? After '+92', only digits allowed.\n";
                continue;
            }
            isValid = true;
        }
        // Case 2: Local format (11 digits ? convert to +92 format)
        else {
            if (number.length() != 11) {
                cout << "? Local number must be exactly 11 digits (e.g., 03001234567).\n";
                continue;
            }
            bool digitsOnly = true;
            for (char c : number) {
                if (!isdigit(c)) {
                    digitsOnly = false;
                    break;
                }
            }
            if (!digitsOnly) {
                cout << "? Local number must contain only digits.\n";
                continue;
            }

            // Convert local (0300...) ? +92300...
            number = "+92" + number.substr(1);
            isValid = true;
        }

    } while (!isValid);

    return number; // Always returns in +92xxxxxxxxxx format
}
//-------------------------------------------------------------------------




//-------------------------------------------------------------------------


//--------------------Enums Collections------------------

enum Gender { OTHER = 0, FEMALE, MALE };



enum RoomType { SINGLE = 0, DOUBLE, SUITE};
enum GuestType { REGULAR = 0, VIP, MEMBER };
enum PositionType { ADMIN = 0, MANAGER, STAFF, UNKNOWN };
enum ServiceType { ROOM_SERVICE = 0, FOOD, LAUNDRY, SPA, TRANSPORT, NONE };
//-------------------------------------------------------------------------

// Date Struct
struct Date {
    int day, month, year;

    Date(int d = 0, int m = 0, int y = 0) {
        day = d;
        month = m;
        year = y;
    }

    // ? Convert Date into time_t
    time_t toTimeT() const {
        tm t = {};
        t.tm_mday = day;
        t.tm_mon = month - 1;   // months: 0-11
        t.tm_year = year - 1900; // years since 1900
        return mktime(&t);
    }
};


//-------------------------------------------------------------------------


//-----------------Classes-------------------


// =================== CLASS HOTEL =====================
class Hotel 
{
private:
    string hotelName;
    int hotelID;
    float rating;  

public:
    Hotel() : hotelName(""), hotelID(0),rating(0.0) 
	{
	
	}
	
	
void setRating(float r) {
        if (r >= 1.0 && r <= 5.0)
            rating = r;
        else
            cout << "Invalid rating! Please enter between 1.0 and 5.0\n";
    }

    float getRating() const 
	{
        return rating;
    }

    void inputHotel() 
	{
                
        hotelName=validName();

        cout << "Enter Hotel ID: ";
        hotelID = validNumber();
        
        cout << "Enter Rating (1.0 - 5.0): ";
        float r;
        cin >> r;
        setRating(r);  
        
    }



    void showHotel() const 
	{
        cout << "Hotel Name: " << hotelName << endl;
        cout << "Hotel ID: " << hotelID << endl;
        cout << "Rating: " << rating << " / 5.0" << endl;
    }
   
   
   //.......save and load from file...... 
    
    void saveToFile(ofstream &fout) {
        fout<<"Hotel Name,Hotel ID, Hotel Rating\n" 
		<< hotelName << " " << "," 
		<< hotelID << "," 
		<<rating<<"\n" 
		<< endl;
		
    }

    void loadFromFile(ifstream &fin) {
        fin >> hotelName >> hotelID >> rating;
    }

    int getHotelID() const
	 {
        return hotelID;
     }
 
};

//---Person Class---
class Person {
protected:
  
    string name;
    Gender gender;
    int age;
    string contactNumber;
    string address;

public:
    Person() {}
    Person( string name, Gender gender, int age, string contact, string address)
        :  name(name), gender(gender), age(age), contactNumber(), address(address) {}
        
        void inputDetails() {
        

        
        name = validName();

        cout << "Enter Age: ";
        age = validNumber();

        cout << "Select Gender (0-OTHER, 1-FEMALE, 2-MALE): ";
        int g = validNumber();
        gender = static_cast<Gender>(g);
        

        
        contactNumber =  validContactNumber();

        
        address = validAddress();
}

    // Virtual function for polymorphism
    virtual void displayDetails() const {
    
        cout << "\nName: " << name
             << "\nGender: " << (gender == MALE ? "Male" : (gender == FEMALE ? "Female" : "Other"))
             << "\nAge: " << age
             << "\nContact: " << contactNumber
             << "\nAddress: " << address << endl;
    }

    
};

// ---Derived class Guest---
class Guest : public Person {
private:
    GuestType type;
    int guestID;
    

public:
    Guest() : Person(), type(type), guestID(0) {}

    void inputDetails() {

        Person::inputDetails();
        cout<<"Enter Guest ID : ";
        guestID = validNumber();
        cout << "Select Guest Type (0-REGULAR, 1-VIP, 2-MEMBER): ";
        int t = validNumber();
        type = static_cast<GuestType>(t);
    }

    // Override displayDetails to follow polymorphism
    void displayDetails() const override {
        Person::displayDetails();
        cout << "Guest ID: " << guestID << endl;
        cout << "Guest Type: " 
             << (type == REGULAR ? "Regular" : (type == VIP ? "VIP" : "Member")) << endl;
    }
    
    //.......save and load from file......
    
    // Save both base and derived data
void saveToFile(ofstream &fout) {
    fout << "Name,Gender,Age,Contact Number,Address,Guest ID,Type\n"
         << name << ","
         << gender << ","
         << age << ","
         << "=\""<< contactNumber << "\"" << ","    //  wrapped in quotes
         << address << ","
         << guestID << ","
         << type
         << "\n";  // newline only (no extra endl needed here)
}


   // Load both base and derived data
void loadFromFile(ifstream &fin) {
     name = validString();
    
    int g;
    fin >> g;
    gender = static_cast<Gender>(g);

    fin >> age;
    fin.ignore(); // to skip newline

    contactNumber = validNumber();
     address = validString();
    fin >> guestID;

    int t;
    fin >> t;
    type = static_cast<GuestType>(t);

    fin.ignore(); // Skip newline at end
}


    int getGuestID() const {
        return guestID;
    }
};

// =================== CLASS ROOM =====================
class Room 
{
private:
    int roomID;
    float chargePerNight;
    
   
    RoomType type;
    bool isAvailable;

public:
    Room() : roomID(0), chargePerNight(0.0), type(SINGLE), isAvailable(true)
	 {
	 
	 }

    void inputRoom() 
	{
        cout << "Enter Room Number: ";
        roomID = validNumber();
        cout << "Enter Price per Night: ";
        chargePerNight = validFloat();
        cout << "Select Room Type (0-SINGLE, 1-DOUBLE, 2-SUITE): ";
        int t;
        t = validNumber();
        type = static_cast<RoomType>(t);

        isAvailable = true; // Default available when adding
        cin.ignore();
    }

    void showRoom() const 
	{
        cout << "Room Number: " << roomID << endl;
        cout << "Price: $" << chargePerNight << endl;
        cout << "Room Type: " << (type == SINGLE ? "Single" : (type == DOUBLE ? "Double" : "Suite")) << endl;
        cout << "Availability: " << (isAvailable ? "Available" : "Occupied") << endl;
    }

    int getRoomID() const
	{
        return roomID;
    }

    void setAvailability(bool status) 
	{
        isAvailable = status;
    }

    bool getAvailability() const 
	{
        return isAvailable;
    }
    
    float getRoomCharge() 
	{
        return chargePerNight;
    }
    
  
  
  //.......save and load from file......
    
    void saveToFile(ofstream &fout) const 
	{
		
    fout<<"Room ID,Charge Per Night,Room Type,Status\n" 
	<< roomID << "," 
	<<chargePerNight << "$,"
	<< type << "," 
	<<isAvailable 
	<<endl;
	
       
}

void loadFromFile(ifstream &fin) {
    fin >> roomID;
    fin >> chargePerNight;

    int tempType;
    fin >> tempType;
    type = static_cast<RoomType>(tempType);

    fin >> isAvailable;
}


};

// =================== CLASS RESERVATION =====================
class Reservation {
private:
    int reservationID;
    int guestID;
    int roomNumber;
    Date checkIn; // composition
    Date checkOut; // composition

public:
    Reservation() : reservationID(0), guestID(0), roomNumber(0) 
	{
        checkIn = {0, 0, 0};
        checkOut = {0, 0, 0};
    }

    void inputReservation() 
	{
        cout << "Enter Reservation ID: ";
        
        reservationID = validNumber();
        
        cout << "Enter Guest ID: ";
        
        guestID = validNumber();
        
        cout << "Enter Room Number: ";
        
        roomNumber = validNumber();
        

        cout << "Enter Check-in Date (dd mm yyyy): ";
        
        cin >> checkIn.day >> checkIn.month >> checkIn.year;
        
        cout << "Enter Check-out Date (dd mm yyyy): ";
        
        cin >> checkOut.day >> checkOut.month >> checkOut.year;
        
        cin.ignore();
    }

    void showReservation() const 
	{
        cout << "Reservation ID: " << reservationID << endl;
        
        cout << "Guest ID: " << guestID << endl;
        
        cout << "Room Number: " << roomNumber << endl;
        
        cout << "Check-in Date: " << checkIn.day << "/" << checkIn.month << "/" << checkIn.year << endl;
        
        cout << "Check-out Date: " << checkOut.day << "/" << checkOut.month << "/" << checkOut.year << endl;
        
    }
    
     int calculateNights() {
        time_t inTime = checkIn.toTimeT();
        time_t outTime = checkOut.toTimeT();
        double seconds = difftime(outTime, inTime);
        int nights = seconds / (60 * 60 * 24);
        return nights > 0 ? nights : 0;
    }


 int getGuestID() const {
        return guestID;
    }

    int getRoomNumber() const {
        return roomNumber;
    }

    int getReservationID() const 
	{
        return reservationID;
    }
    
   // -------- Save to file --------
    void saveToFile(ofstream &fout) const 
	{
        fout<<"Reservation ID,Guest ID,Room Number,Check In Date,Check Out Date\n" 
		     << reservationID << ","
             << guestID << ","
             << roomNumber << ","
             << checkIn.day << "/" << checkIn.month << "/" << checkIn.year << ","
             << checkOut.day << "/" << checkOut.month << "/" << checkOut.year 
             << endl;
             
    }
    
// -------- Load from file --------
    void loadFromFile(ifstream &fin) {
        fin >> reservationID 
            >> guestID 
            >> roomNumber 
            >> checkIn.day >> checkIn.month >> checkIn.year
            >> checkOut.day >> checkOut.month >> checkOut.year;
    }

   
};

//---Service Class---

class Service 
{
private:
    ServiceType serviceType;
    
    float serviceCharge;

public:
    Service(ServiceType type = FOOD, float charge = 0) 
	{
	   serviceType = type;
	   
	   serviceCharge = charge; 
	
	}

    void setService(ServiceType type, float charge) 
	{
        serviceType = type;
        
        serviceCharge = charge;
    }

    float getServiceCharge() 
	{
        return serviceCharge;
    }

    ServiceType getServiceType() 
	{
        return serviceType;
    }


   

    void showService() 
	{
        string type;
        switch (serviceType) 
		{
            case ROOM_SERVICE:
            	
			type = "room";
			
			break;
			
            case FOOD:
            	
			type = "food"; 
			
			break;
			
            case LAUNDRY: 
            
			type = "laundry";
			 
			break;
			
            case SPA:
			 
			type = "spa";
			 
			break;
			
			case TRANSPORT: 
			
			
			type = "transport"; 
			break;
			
            case NONE:
			 
			type = "none"; 
			
			break;
        }
        cout << "Service Type: " << type << ", Charge: $" << serviceCharge << endl;
    }
    
    
    
    //.......save and load from file......
    
    void saveToFile(ofstream &fout) const 
	{
    fout<<"Service Type,Service Charge\n"
	<< serviceType << "," 
	<< serviceCharge 
	<< endl;
	     
   
}

void loadFromFile(ifstream &fin) {
    int typeInt;     // Save enum as int
    fin >> typeInt;
    serviceType = static_cast<ServiceType>(typeInt);
    fin >> serviceCharge;
}

    
};

//---Bill Class---

class Bill 
{
private:
    int billID;
    Guest* guest;       // Aggregation
    Room* room;         // Aggregation
    float roomCharge;
    float serviceCharges;
    float totalAmount;

public:
    Bill() 
	{
        billID = 0;
        guest = nullptr;
        room = nullptr;
        roomCharge = 0.0;
        serviceCharges = 0.0;
        totalAmount = 0.0;
    }

    void setBill(int id, Guest* g, Room* r, float rCharge, float sCharge) 
	{
        billID = id;
        guest = g;
        room = r;
        roomCharge = rCharge;
        serviceCharges = sCharge;
        totalAmount = roomCharge + serviceCharges;
    }

    void showBill() const 
	{
        cout << "\n======= BILL DETAILS =======\n";
        cout << "Bill ID       : " << billID << endl;
        cout << "Guest ID      : " << (guest ? guest->getGuestID() : -1) << endl;
        cout << "Room ID       : " << (room ? room->getRoomID() : -1) << endl;
        cout << "Room Charge   : " << roomCharge << " PKR\n";
        cout << "Service Charge: " << serviceCharges << " PKR\n";
        cout << "-----------------------------\n";
        cout << "Total Amount  : " << totalAmount << " PKR\n";
        cout << "=============================\n";
    }
    
   
};



//---Login Class---

class Login {
    string usernames[3] = {"admin", "manager", "staff"};
    string passwords[3] = {"admin123", "manager123", "staff123"};
    PositionType positions[3] = {ADMIN, MANAGER, STAFF};

public:
    PositionType currentPosition = UNKNOWN; // Initially no one is logged in

    bool authenticate(string u, string p) {
        for (int i = 0; i < 3; i++) {
            if (usernames[i] == u && passwords[i] == p) {
                currentPosition = positions[i];
               
                return true;
            }
        }
        cout << "Invalid username or password!" << endl;
        return false;
    }

    void logout() {
        if (currentPosition != UNKNOWN) {
            cout << "User logged out successfully." << endl;
            currentPosition = UNKNOWN;
        } else {
            cout << "No user is currently logged in!" << endl;
        }
    }

    bool isLoggedIn() {
        return currentPosition != UNKNOWN;
    }
};

//-------------------------------------------------------------------

//----- Arrays and Counts / Collections---

Hotel hotels[100];

Room rooms[1000];

Guest guests[1000];

Reservation reservations[1000];

Service services[1000];



int hotelCount = 0;

int roomCount = 0;
 
int guestCount = 0;
 
int reservationCount = 0;
  
int serviceCount=0;



//-------------------------------------------------------------------


// Helper function to convert enum to string
string getServiceTypeName(ServiceType type) {
    switch(type) {
        case ROOM_SERVICE: return "Room Service";
        case FOOD: return "Food";
        case LAUNDRY: return "Laundry";
        case SPA: return "Spa";
        case TRANSPORT: return "Transport";
        case NONE: return "None";
        default: return "Unknown";
    }
}

//------------------------------------------------------------


//------load and save hotels------

void loadHotels() {
    ifstream fin("C:\\Users\\NOOR COMP\\Documents\\hotels2.csv");
    hotelCount = 0;

    string header;
    getline(fin, header);  // skip the first line (headings)

    while (fin && hotelCount < 100) {
        hotels[hotelCount].loadFromFile(fin);
        if (fin) hotelCount++;
    }
    fin.close();
}


void saveHotels() {
    ofstream fout("C:\\Users\\NOOR COMP\\Documents\\hotels2.csv", ios::app);
    fout << "HotelName,HotelID\n";
    for (int i = 0; i < hotelCount; i++)
        hotels[i].saveToFile(fout);
    fout.close();
}

//--------------------------------------------------------------------------

//------load and save rooms------

void loadRooms()
{

ifstream fin("C:\\Users\\NOOR COMP\\Documents\\rooms1.csv");
fin >> roomCount;
for (int i = 0; i < roomCount; i++) {
    rooms[i].loadFromFile(fin);
}
fin.close();
}

void saveRooms()
{

ofstream fout("C:\\Users\\NOOR COMP\\Documents\\rooms1.csv", ios::app);
fout << roomCount << endl;  // Save count first
for (int i = 0; i < roomCount; i++) {
    rooms[i].saveToFile(fout);
}
fout.close();
}


//--------------------------------------------------------

//------load and save guests------

// Loading
void loadGuests() {
    ifstream fin("C:\\Users\\NOOR COMP\\Documents\\guests1.csv");
    fin >> guestCount;
    for (int i = 0; i < guestCount; i++) {
        guests[i].loadFromFile(fin);
    }
    fin.close();
}


// Saving
void saveGuests() {
    ofstream fout("C:\\Users\\NOOR COMP\\Documents\\guests1.csv", ios::app);
    fout << guestCount << endl;
    for (int i = 0; i < guestCount; i++) {
        guests[i].saveToFile(fout);
    }
    fout.close();
}



//--------------------------------------------------------

//------load and save Reservations------


// ---- Save Reservations ----
void saveReservations() {
    ofstream fout("C:\\Users\\NOOR COMP\\Documents\\reservations2.csv", ios::app); 
    if (!fout) {
        cout << "Error opening file for saving.\n";
        return;
    }

    for (int i = 0; i < reservationCount; i++) {
        reservations[i].saveToFile(fout);
    }

    fout.close();
   
}

// ---- Load Reservations ----
void loadReservations() {
    ifstream fin("C:\\Users\\NOOR COMP\\Documents\\reservations2.csv");
    if (!fin) {
        cout << "No saved reservations found.\n";
        return;
    }

    reservationCount = 0;
    while (fin && reservationCount < 1000) {
        reservations[reservationCount].loadFromFile(fin);
        if (fin) reservationCount++;
    }

    fin.close();
    
}

//--------------------------------------------------------
//------load and save services------

void loadServices()
{
ifstream fin("C:\\Users\\NOOR COMP\\Documents\\services1.csv ");
fin >> serviceCount;
for (int i = 0; i < serviceCount; i++) {
    services[i].loadFromFile(fin);
}
fin.close();
}

void saveServices()
{

ofstream fout("C:\\Users\\NOOR COMP\\Documents\\services1.csv", ios::app);
fout << serviceCount << endl;
for (int i = 0; i < serviceCount; i++) {
    services[i].saveToFile(fout);
}
fout.close();
}

//------------------------------------------------------------------------------------------------

// Hotel Management
void hotelManagementMenu() 
{
    int choice;
    
    do {
        cout << "\n--- Hotel Management Menu ---\n";
        cout << "\n1. Add Hotel\n";
        cout << "2. Show Hotels\n";
        cout << "3. Search Hotel by ID\n";
        cout << "4. Delete Hotel\n";
        cout << "5. Update Hotel\n";   // ? New Option
        cout << "6. Go Back\n";
        cout << "Enter your choice: ";
        choice = validNumber();

        if (choice == 1) // Add
        {
            if (hotelCount < 100) {
                hotels[hotelCount++].inputHotel();
                saveHotels();
            } 
            else {
                cout << "Hotel list is full!\n";
            }
        } 
        else if (choice == 2) // Show
        {
            for (int i = 0; i < hotelCount; i++) {
                hotels[i].showHotel();
                cout << "----------------------\n";
            }
        } 
        else if (choice == 3) // Search
        {
            int id;
            cout << "Enter Hotel ID to search: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < hotelCount; i++) {
                if (hotels[i].getHotelID() == id) {
                    hotels[i].showHotel();
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Hotel not found!\n";
        } 
        else if (choice == 4) // Delete
        {   
            int id;
            cout << "Enter Hotel ID to delete: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < hotelCount; i++) {
                if (hotels[i].getHotelID() == id) {
                    for (int j = i; j < hotelCount - 1; j++) {
                        hotels[j] = hotels[j + 1];
                    }
                    hotelCount--;
                    saveHotels();
                    cout << "Hotel deleted successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Hotel not found!\n";
        }
        else if (choice == 5) // ? Update
        {
            int id;
            cout << "Enter Hotel ID to update: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < hotelCount; i++) {
                if (hotels[i].getHotelID() == id) {
                    cout << "Current Hotel Details:\n";
                    hotels[i].showHotel();

                    cout << "\nEnter new details:\n";
                    hotels[i].inputHotel();  // overwrite with new input
                    saveHotels();
                    cout << "Hotel updated successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Hotel not found!\n";
        }

    } while (choice != 6); // Go Back
}

// Room Management
void roomManagementMenu() 
{
    int choice;
    
    do {
        cout << "\n--- Room Management Menu ---\n";
        cout << "\n1. Add Room\n";
        cout << "2. Show Rooms\n";
        cout << "3. Search Room by ID\n";
        cout << "4. Delete Room\n";
        cout << "5. Update Room\n";   // ? New Option
        cout << "6. Go Back\n";
        cout << "Enter your choice: ";
        choice = validNumber();

        if (choice == 1) // Add
        {
            if (roomCount < 100) {
                rooms[roomCount++].inputRoom();
                saveRooms();
            } 
            else {
                cout << "Room list is full!\n";
            }
        } 
        else if (choice == 2) // Show
        {
            for (int i = 0; i < roomCount; i++) {
                rooms[i].showRoom();
                cout << "----------------------\n";
            }
        } 
        else if (choice == 3) // Search
        {
            int id;
            cout << "Enter Room ID to search: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < roomCount; i++) {
                if (rooms[i].getRoomID() == id) {
                    rooms[i].showRoom();
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Room not found!\n";
        } 
        else if (choice == 4) // Delete
        {   
            int id;
            cout << "Enter Room ID to delete: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < roomCount; i++) {
                if (rooms[i].getRoomID() == id) {
                    for (int j = i; j < roomCount - 1; j++) {
                        rooms[j] = rooms[j + 1];
                    }
                    roomCount--;
                    saveRooms();
                    cout << "Room deleted successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Room not found!\n";
        }
        else if (choice == 5) // ? Update
        {
            int id;
            cout << "Enter Room ID to update: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < roomCount; i++) {
                if (rooms[i].getRoomID() == id) {
                    cout << "Current Room Details:\n";
                    rooms[i].showRoom();

                    cout << "\nEnter new details:\n";
                    rooms[i].inputRoom(); // overwrite with new details
                    saveRooms();
                    cout << "Room updated successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Room not found!\n";
        }

    } while (choice != 6); // Go Back
}


//--------Guest Management-------
void guestManagementMenu() 
{
    int choice;
    do {
        cout << "\n--- Guest Management Menu ---\n";
        cout << "\n1. Add Guest\n";
        cout << "2. Show Guests\n";
        cout << "3. Search Guest by ID\n";
        cout << "4. Delete Guest\n";
        cout << "5. Update Guest\n";   // ? New option
        cout << "6. Go Back\n";
        cout << "Enter your choice: ";
        choice = validNumber();

        if (choice == 1) // Add
        {
            if (guestCount < 100) {
                guests[guestCount++].inputDetails();
                saveGuests();
            } 
            else {
                cout << "Guest list is full!\n";
            }
        } 
        else if (choice == 2) // Show
        {
            for (int i = 0; i < guestCount; i++) {
                guests[i].displayDetails();
                cout << "----------------------\n";
            }
        } 
        else if (choice == 3) // Search
        {
            int id;
            cout << "Enter Guest ID to search: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < guestCount; i++) {
                if (guests[i].getGuestID() == id) {
                    guests[i].displayDetails();
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Guest not found!\n";
        } 
        else if (choice == 4) // Delete
        {   
            int id;
            cout << "Enter Guest ID to delete: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < guestCount; i++) {
                if (guests[i].getGuestID() == id) {
                    for (int j = i; j < guestCount - 1; j++) {
                        guests[j] = guests[j + 1];
                    }
                    guestCount--;
                    saveGuests();
                    cout << "Guest deleted successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Guest not found!\n";
        }
        else if (choice == 5) // ? Update
        {
            int id;
            cout << "Enter Guest ID to update: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < guestCount; i++) {
                if (guests[i].getGuestID() == id) {
                    cout << "Current Guest Details:\n";
                    guests[i].displayDetails();

                    cout << "\nEnter new details:\n";
                    guests[i].inputDetails(); // overwrite old details
                    saveGuests(); // save changes
                    cout << "Guest updated successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Guest not found!\n";
        }

    } while (choice != 6); // Go Back
}

  
//------Reservation Management-------
void reservationManagementMenu() 
{
    int choice;

    do {
        cout << "\n--- Reservation Management Menu ---\n";
        cout << "\n1. Add Reservation\n";
        cout << "2. Show Reservations\n";
        cout << "3. Search Reservation by ID\n";
        cout << "4. Delete Reservation\n";
        cout << "5. Update Reservation\n";  // ? New Option
        cout << "6. Go Back\n";
        cout << "Enter your choice: ";
        choice = validNumber();

        if (choice == 1) // Add
        {
            if (reservationCount < 100) {
                reservations[reservationCount++].inputReservation();
                saveReservations(); // save after add
            } else {
                cout << "Reservation list is full!\n";
            }
        }
        else if (choice == 2) // Show
        {
            for (int i = 0; i < reservationCount; i++) {
                reservations[i].showReservation();
                cout << "----------------------\n";
            }
        }
        else if (choice == 3) // Search
        {
            int id;
            cout << "Enter Reservation ID to search: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < reservationCount; i++) {
                if (reservations[i].getReservationID() == id) {
                    reservations[i].showReservation();
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Reservation not found!\n";
        }
        else if (choice == 4) // Delete
        {
            int id;
            cout << "Enter Reservation ID to delete: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < reservationCount; i++) {
                if (reservations[i].getReservationID() == id) {
                    // Shift left
                    for (int j = i; j < reservationCount - 1; j++) {
                        reservations[j] = reservations[j + 1];
                    }
                    reservationCount--;
                    saveReservations(); // save after delete
                    cout << "Reservation deleted successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Reservation not found!\n";
        }
        else if (choice == 5) // ? Update
        {
            int id;
            cout << "Enter Reservation ID to update: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < reservationCount; i++) {
                if (reservations[i].getReservationID() == id) {
                    cout << "Current Reservation Details:\n";
                    reservations[i].showReservation();
                    
                    cout << "\nEnter new details:\n";
                    reservations[i].inputReservation(); // Re-input reservation details
                    saveReservations(); // save after update
                    cout << "Reservation updated successfully.\n";
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Reservation not found!\n";
        }

    } while (choice != 6); // Go Back
}


//----------Service Management--------
void serviceManagementMenu() 
{
    int choice;
    do 
    {
        cout << "\n--- Service Management Menu ---\n";
        cout << "\n1. Add Service\n";
        cout << "2. Show Services\n";
        cout << "3. Update Service\n";
        cout << "4. Delete Service\n";
        cout << "5. Go Back\n";
        cout << "Enter your choice: ";
        choice = validNumber();

        if (choice == 1) // Add Service
        {
            if (serviceCount < 1000) 
            {
                int typeInput;
                float charge;
                cout << "Enter Service Type:\n";
                cout << "0. Room Service\n1. Food\n2. Laundry\n3. Spa\n4. Transport\n5. None\nChoice: ";
                typeInput = validNumber();
                
                while (typeInput < 0 || typeInput > 5) 
                {
                    cout << "Invalid input. Enter choice (0-5): ";
                    typeInput = validNumber();
                }

                cout << "Enter Service Charge: ";
                cin >> charge;

                services[serviceCount].setService(static_cast<ServiceType>(typeInput), charge);
                serviceCount++;
                cout << "Service added successfully!\n";
                saveServices();
            } 
            else 
            {
                cout << "Service list is full!\n";
            }
        } 
        else if (choice == 2) // Show Services
        {
            if (serviceCount == 0) 
            {
                cout << "No services available.\n";
            } 
            else 
            {
                cout << "\n--- List of Services ---\n";
                for (int i = 0; i < serviceCount; i++) 
                {
                    cout << "Service Number: " << (i + 1) << "\n";
                    cout << "Service Type: " << getServiceTypeName(services[i].getServiceType()) << "\n";
                    cout << "Service Charge: $" << services[i].getServiceCharge() << "\n";
                    cout << "----------------------\n";
                }
            }
        }
        else if (choice == 3) // Update Service
        {
            if (serviceCount == 0) 
            {
                cout << "No services available to update.\n";
            } 
            else 
            {
                int index;
                cout << "Enter Service Number to Update (1-" << serviceCount << "): ";
                index = validNumber();
                while (index < 1 || index > serviceCount) 
                {
                    cout << "Invalid number. Enter again: ";
                    index = validNumber();
                }
                index--; // adjust for 0-based array

                int typeInput;
                float charge;
                cout << "Enter New Service Type:\n";
                cout << "0. Room Service\n1. Food\n2. Laundry\n3. Spa\n4. Transport\n5. None\nChoice: ";
                typeInput = validNumber();
                while (typeInput < 0 || typeInput > 5) 
                {
                    cout << "Invalid input. Enter choice (0-5): ";
                    typeInput = validNumber();
                }

                cout << "Enter New Service Charge: ";
                cin >> charge;

                services[index].setService(static_cast<ServiceType>(typeInput), charge);
                cout << "Service updated successfully!\n";
                saveServices();
            }
        }
        else if (choice == 4) // Delete Service
        {
            if (serviceCount == 0) 
            {
                cout << "No services available to delete.\n";
            } 
            else 
            {
                int index;
                cout << "Enter Service Number to Delete (1-" << serviceCount << "): ";
                index = validNumber();
                while (index < 1 || index > serviceCount) 
                {
                    cout << "Invalid number. Enter again: ";
                    index = validNumber();
                }
                index--; // adjust for 0-based array

                for (int i = index; i < serviceCount - 1; i++) 
                {
                    services[i] = services[i + 1];
                }
                serviceCount--;
                cout << "Service deleted successfully!\n";
                saveServices();
            }
        }
    } 
    while (choice != 5);
}

//------------Bill Management-------------
void billManagementMenu() {
    int guestID, roomID;
    float serviceTotal = 0;

    cout << "\n--- Bill Management Menu ---\n";

    // Get guest pointer using ID
    cout << "Enter Guest ID: ";
    guestID = validNumber();
    Guest* guestPtr = nullptr;
    for (int i = 0; i < guestCount; i++) {
        if (guests[i].getGuestID() == guestID) {
            guestPtr = &guests[i];
            break;
        }
    }
    if (!guestPtr) {
        cout << "? Guest not found!\n";
        return;
    }

    // Get room pointer using ID
    cout << "Enter Room ID: ";
    roomID = validNumber();
    Room* roomPtr = nullptr;
    for (int i = 0; i < roomCount; i++) {
        if (rooms[i].getRoomID() == roomID) {
            roomPtr = &rooms[i];
            break;
        }
    }
    if (!roomPtr) {
        cout << "? Room not found!\n";
        return;
    }

    // Find reservation for this Guest & Room
    Reservation resObj;
bool found = false;   // <-- declare and initialize

for (int i = 0; i < reservationCount; i++) {
    if (reservations[i].getGuestID() == guestID &&
        reservations[i].getRoomNumber() == roomID) {
        resObj = reservations[i];
        found = true;   // <-- mark as found
        break;
    }
}

if (!found) {
    cout << "? Reservation not found for this Guest & Room!\n";
    return;
}

    // Automatically calculate nights stayed
    int nights = resObj.calculateNights();
    if (nights <= 0) {
        cout << " Invalid check-in/check-out dates. Nights = " << nights << endl;
        return;
    }

    // Room charges
    float roomCharge = roomPtr->getRoomCharge() * nights;
    cout << "Room Charge (" << nights << " nights): " << roomCharge << " PKR\n";

    // Ask for service charges
    char serviceChoice;
    cout << "Did the guest use any services? (y/n): ";
    cin >> serviceChoice;

    if (serviceChoice == 'y' || serviceChoice == 'Y') {
        for (int i = 0; i < serviceCount; i++) {
            cout << "\nService " << (i + 1) << ":\n";
            services[i].showService();
            cout << "Include this service in bill? (y/n): ";
            char include;
            cin >> include;
            if (include == 'y' || include == 'Y') {
                serviceTotal += services[i].getServiceCharge();
            }
        }
    }

    // Create and display bill using aggregation
    int billID = 1000 + rand() % 9000;
    Bill bill;
    bill.setBill(billID, guestPtr, roomPtr, roomCharge, serviceTotal);
    bill.showBill();
}

//login function

void loggedYouIn(Login& login, string& loggedInName) {
    string username, password;
   cout << "\n----- LOGIN SYSTEM -----" << endl;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;
    
    if (login.authenticate(username, password)) {
        cout << "\nLogin successful...!" << endl;
        cout << "You are logged in as: ";

        switch (login.currentPosition) {
            case ADMIN:  
			cout << "Admin" << endl; 
			break;
            case MANAGER: 
			cout << "Manager" << endl; 
			break;
            case STAFF:   
			cout << "Staff" << endl; 
			break;
            default:      
			cout << "Unknown" << endl; 
			break;
        }
        
        cout << "------------------------" << endl;

       cout << "\nEnter your name: ";
        cin.ignore();  // clear newline from previous input
        getline(cin, loggedInName);

        cout << "\n Welcome, "<< loggedInName << "!" << endl;
        cout << "------------------------\n" << endl;
    } else {
        cout << "\n Invalid username or password!" << endl;
        exit(0); // Exit or retry can be implemented if needed
    }
    
    
}




// Main Menu
void mainMenu(Login &login, string &loggedInName) 
{
	
    int choice;
    do 
	{
        cout << "\n===== HOTEL MANAGEMENT SYSTEM =====\n";
        cout << "1. Hotel Management\n";
        cout << "2. Room Management\n";
        cout << "3. Guest Management\n";
        cout << "4. Reservation Management\n";
        cout << "5. Service Management\n";
        cout << "6. Bill Management\n";
        cout << "7. Logout\n";
        cout << "8. Exit\n";
        cout << "Enter your choice: ";
        choice = validNumber();
        switch (choice) 
		{
            case 1: 
			hotelManagementMenu(); 
			break;
            case 2: 
			roomManagementMenu(); 
			break;
            case 3: 
			guestManagementMenu(); 
			break;
            case 4: 
			reservationManagementMenu(); 
			break;
            case 5: 
			serviceManagementMenu();
			break;
            case 6:
			billManagementMenu(); 
			break;
			
			case 7: // Logout
			
                cout << "\nYou are logged out as " << loggedInName << " (";
                switch(login.currentPosition) {
                    case ADMIN: cout << "Admin"; break;
                    case MANAGER: cout << "Manager"; break;
                    case STAFF: cout << "Staff"; break;
                    default: cout << "Unknown"; break;
                }
                cout << ").\n\n";

                // Clear user info
                loggedInName = "";
                login.logout();  // Reset currentPosition to UNKNOWN

                // Go back to login
                loggedYouIn(login, loggedInName);
                break;

            case 8: // Exit program
                cout << "Exiting the program. Thank you!\n";
                exit(0);


            default: cout << "Invalid choice! Try again.\n";
        }
    } while (true);
}

int main() 
{
    Login login;
    string name;

   
   loggedYouIn(login, name);


    // Main menu loop
    mainMenu(login, name);
           

    // Load data once
    loadHotels();
    loadRooms();
    loadGuests();
    loadReservations();
    loadServices(); 
    
   
    return 0;
}
